# 🤖 Teams Incident Management Bot — POC

A Microsoft Teams chatbot that guides users through incident creation via conversational Q&A and stores incidents in an Excel file (ServiceNow-ready for production).

```
Teams Chat → Bot Q&A → Excel File (incidents.xlsx)
```

---

## 📁 Project Structure

```
incident-bot/
├── index.js                    ← Bot server entry point
├── package.json
├── .env.example                ← Copy to .env and fill in values
│
├── bot/
│   └── incidentBot.js          ← TeamsActivityHandler (routes messages)
│
├── dialogs/
│   └── incidentDialog.js       ← Waterfall Q&A dialog (7 steps)
│
├── cards/
│   ├── welcomeCard.js          ← Adaptive Card: welcome screen
│   ├── confirmationCard.js     ← Adaptive Card: review before submit
│   └── successCard.js          ← Adaptive Card: success + ticket ID
│
├── services/
│   └── excelService.js         ← Excel read/write (swap with ServiceNow later)
│
├── scripts/
│   ├── setup.js                ← 🚀 ONE-COMMAND Azure setup
│   ├── createManifest.js       ← Generates Teams app manifest zip
│   └── updateEndpoint.js       ← Updates bot endpoint with tunnel URL
│
├── data/
│   └── incidents.xlsx          ← Auto-created on first incident
│
└── manifest/
    ├── manifest.json           ← Auto-generated
    ├── color.png               ← Replace with your 192x192 icon
    ├── outline.png             ← Replace with your 32x32 icon
    └── incident-bot.zip        ← Upload this to Teams
```

---

## ✅ Prerequisites

| Tool | Version | Install |
|---|---|---|
| Node.js | 18+ | https://nodejs.org |
| Azure CLI | Latest | https://aka.ms/installazurecli |
| Azure Account | Active subscription | https://portal.azure.com |
| Microsoft 365 | With Teams | Via your org |

---

## 🚀 Quick Start (3 Steps)

### Step 1 — Clone & Install

```bash
git clone <your-repo>
cd incident-bot
npm install
```

### Step 2 — Run the Setup Script

> This creates all Azure resources and writes your `.env` automatically.

```bash
# Login to Azure first
az login

# Run setup
node scripts/setup.js
```

You'll be prompted for:
- **Bot name** (e.g. `IncidentBot-POC`)
- **Resource group** (auto-suggested)
- **Azure region** (default: `eastus`)

The script will:
1. ✅ Create Azure Resource Group
2. ✅ Create Azure AD App Registration
3. ✅ Create Azure Bot Service (free F0 tier)
4. ✅ Enable Microsoft Teams channel
5. ✅ Write your `.env` file with all credentials

### Step 3 — Start the Bot

**Terminal 1 — Start bot server:**
```bash
npm start
```

**Terminal 2 — Start tunnel:**
```bash
npm run tunnel
# Copy the URL shown, e.g.: https://incident-bot-poc.loca.lt
```

**Terminal 3 — Update endpoint + manifest:**
```bash
node scripts/updateEndpoint.js https://incident-bot-poc.loca.lt
```

---

## 📱 Add Bot to Teams

1. The `updateEndpoint.js` script auto-generates `manifest/incident-bot.zip`
2. Open **Microsoft Teams**
3. Click **Apps** (left sidebar) → **Manage your apps**
4. Click **Upload an app** → **Upload a custom app**
5. Select `manifest/incident-bot.zip`
6. Click **Add**

You can now chat with the bot! Type `new incident` to start.

---

## 💬 Bot Commands

| Command | Description |
|---|---|
| `new incident` | Start the incident creation flow |
| `help` | Show available commands |
| `restart` | Reset current conversation |

---

## 📋 Incident Creation Flow

```
User: new incident
Bot:  Step 1/7 — Title: What's the short description?
User: Login page not loading

Bot:  Step 2/7 — Category: [Software] [Hardware] [Network] [Security] [Other]
User: Software

Bot:  Step 3/7 — Impact: [🔴 High] [🟡 Medium] [🟢 Low]
User: High

Bot:  Step 4/7 — Urgency: [1-Critical] [2-High] [3-Medium] [4-Low]
User: 1 - Critical

Bot:  Step 5/7 — Affected Service?
User: Customer Portal

Bot:  Step 6/7 — Description?
User: Users can't log in since 9am, affects all customers

Bot:  Step 7/7 — Your email?
User: john.doe@company.com

Bot:  [Shows confirmation card]
User: yes

Bot:  ✅ Incident INC-20240601-A3F1 created!
```

---

## 📊 Excel File Format

Incidents are saved to `data/incidents.xlsx` with these columns:

| Column | Description |
|---|---|
| Incident ID | Auto-generated: `INC-YYYYMMDD-XXXX` |
| Title | Short description |
| Category | Software / Hardware / Network / Security / Other |
| Impact | High / Medium / Low |
| Urgency | 1-Critical through 4-Low |
| Affected Service | System/service name |
| Description | Full details |
| Reporter | Email address |
| Reporter Name | Display name from Teams |
| Status | Open / In Progress / Resolved |
| Created At | Timestamp |
| Updated At | Timestamp |

---

## 🔄 Replacing Excel with ServiceNow

When you're ready for production, replace `services/excelService.js`:

```javascript
// services/serviceNowService.js  ← swap this in
async createIncident(data) {
  const response = await axios.post(
    `https://${process.env.SN_INSTANCE}.service-now.com/api/now/table/incident`,
    {
      short_description: data.title,
      impact:            data.impact === 'High' ? '1' : data.impact === 'Medium' ? '2' : '3',
      urgency:           data.urgency.charAt(0),
      description:       data.description,
      category:          data.category.toLowerCase(),
      caller_id:         data.reporter
    },
    {
      auth: {
        username: process.env.SN_USER,
        password: process.env.SN_PASSWORD
      }
    }
  );
  return response.data.result;
}
```

Then in `dialogs/incidentDialog.js`, change:
```javascript
// const { ExcelService } = require('../services/excelService');
const { ServiceNowService } = require('../services/serviceNowService');
this.excelService = new ServiceNowService();
```

---

## 🔧 Configuration Reference (.env)

```env
# Azure Bot (from setup.js output)
MicrosoftAppId=<your-app-id>
MicrosoftAppPassword=<your-app-secret>
MicrosoftAppTenantId=<your-tenant-id>

# Server
PORT=3978

# Excel storage path
EXCEL_FILE_PATH=./data/incidents.xlsx

# Tunnel URL (update after starting tunnel)
TUNNEL_URL=https://incident-bot-poc.loca.lt
```

---

## 🐛 Troubleshooting

| Problem | Solution |
|---|---|
| Bot not responding | Check tunnel is running and endpoint URL is correct in Azure Portal |
| "Unauthorized" error | Verify `MicrosoftAppId` and `MicrosoftAppPassword` in `.env` |
| Excel not saving | Check `data/` folder exists and has write permissions |
| Teams upload fails | Ensure your M365 account has "Upload custom apps" permission |
| Tunnel URL changes | Re-run `node scripts/updateEndpoint.js <new-url>` |

---

## 🚢 Production Upgrade Path

```
POC (Now)                    Production
─────────────────────────    ─────────────────────────
Memory state storage    →    Azure Cosmos DB
Excel file              →    ServiceNow Table API
Local tunnel (ngrok)    →    Azure App Service
Manual deploy           →    GitHub Actions CI/CD
Console logging         →    Azure Application Insights
```

---

## 📄 License

MIT — free for POC and internal use.
