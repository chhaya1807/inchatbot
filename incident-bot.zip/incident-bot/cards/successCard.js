// ============================================================
//  cards/successCard.js
//  Shown after incident is successfully created in Excel
// ============================================================

function SuccessCard(incident) {
  return {
    type: 'AdaptiveCard',
    $schema: 'http://adaptivecards.io/schemas/adaptive-card.json',
    version: '1.4',
    body: [
      {
        type: 'ColumnSet',
        columns: [
          {
            type: 'Column',
            width: 'auto',
            items: [{ type: 'TextBlock', text: '✅', size: 'ExtraLarge' }]
          },
          {
            type: 'Column',
            width: 'stretch',
            items: [
              {
                type: 'TextBlock',
                text: 'Incident Created Successfully!',
                weight: 'Bolder',
                size: 'Medium',
                color: 'Good',
                wrap: true
              },
              {
                type: 'TextBlock',
                text: `ID: **${incident.incidentId}**`,
                size: 'Default',
                spacing: 'None',
                wrap: true
              }
            ]
          }
        ]
      },
      { type: 'Separator', spacing: 'Medium' },
      {
        type: 'FactSet',
        spacing: 'Small',
        facts: [
          { title: '📝 Title',            value: incident.title },
          { title: '⚡ Impact',           value: incident.impact },
          { title: '🚨 Urgency',          value: incident.urgency },
          { title: '🖥️ Service',          value: incident.affectedService },
          { title: '📊 Status',           value: '🟡 Open' },
          { title: '🕐 Created',          value: incident.createdAt }
        ]
      },
      {
        type: 'TextBlock',
        text: 'The incident has been logged in the Excel tracker. Type **new incident** to log another.',
        wrap: true,
        isSubtle: true,
        size: 'Small',
        spacing: 'Medium'
      }
    ]
  };
}

module.exports = { SuccessCard };
