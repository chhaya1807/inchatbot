// ============================================================
//  cards/welcomeCard.js
//  Adaptive Card shown when bot is first installed / added
// ============================================================

const WelcomeCard = {
  type: 'AdaptiveCard',
  $schema: 'http://adaptivecards.io/schemas/adaptive-card.json',
  version: '1.4',
  body: [
    {
      type: 'ColumnSet',
      columns: [
        {
          type: 'Column',
          width: 'auto',
          items: [
            {
              type: 'TextBlock',
              text: '🤖',
              size: 'ExtraLarge'
            }
          ]
        },
        {
          type: 'Column',
          width: 'stretch',
          items: [
            {
              type: 'TextBlock',
              text: 'Incident Management Bot',
              weight: 'Bolder',
              size: 'Large',
              color: 'Accent'
            },
            {
              type: 'TextBlock',
              text: 'POC — Excel Backend',
              size: 'Small',
              isSubtle: true,
              spacing: 'None'
            }
          ]
        }
      ]
    },
    {
      type: 'TextBlock',
      text: "I'll help you create and track incidents through a quick Q&A process.",
      wrap: true,
      spacing: 'Medium'
    },
    {
      type: 'FactSet',
      spacing: 'Medium',
      facts: [
        { title: '📋 Create Incident', value: 'Type **new incident** or click below' },
        { title: '❓ Help',            value: 'Type **help** for all commands' },
        { title: '🔄 Reset',           value: 'Type **restart** to start over anytime' }
      ]
    }
  ],
  actions: [
    {
      type: 'Action.Submit',
      title: '📋 Create New Incident',
      style: 'positive',
      data: { msteams: { type: 'imBack', value: 'new incident' } }
    }
  ]
};

module.exports = { WelcomeCard };
