// ============================================================
//  cards/confirmationCard.js
//  Shows incident summary before final submission
// ============================================================

function ConfirmationCard(data) {
  // Map urgency number to label
  const urgencyMap = {
    '1 - Critical': '🔴 1 - Critical',
    '2 - High':     '🟠 2 - High',
    '3 - Medium':   '🟡 3 - Medium',
    '4 - Low':      '🟢 4 - Low'
  };

  return {
    type: 'AdaptiveCard',
    $schema: 'http://adaptivecards.io/schemas/adaptive-card.json',
    version: '1.4',
    body: [
      {
        type: 'TextBlock',
        text: '📋 Incident Summary — Please Review',
        weight: 'Bolder',
        size: 'Medium',
        color: 'Accent',
        wrap: true
      },
      {
        type: 'TextBlock',
        text: 'Review the details below before submitting.',
        isSubtle: true,
        size: 'Small',
        wrap: true,
        spacing: 'None'
      },
      { type: 'Separator', spacing: 'Medium' },
      {
        type: 'FactSet',
        spacing: 'Medium',
        facts: [
          {
            title: '📝 Title',
            value: data.title || 'N/A'
          },
          {
            title: '🏷️ Category',
            value: data.category || 'N/A'
          },
          {
            title: '⚡ Impact',
            value: data.impact || 'N/A'
          },
          {
            title: '🚨 Urgency',
            value: urgencyMap[data.urgency] || data.urgency || 'N/A'
          },
          {
            title: '🖥️ Affected Service',
            value: data.affectedService || 'N/A'
          },
          {
            title: '👤 Reporter',
            value: `${data.reporterName || ''} (${data.reporter || 'N/A'})`
          }
        ]
      },
      {
        type: 'TextBlock',
        text: `📄 **Description:**\n${data.description || 'N/A'}`,
        wrap: true,
        spacing: 'Medium'
      }
    ]
  };
}

module.exports = { ConfirmationCard };
