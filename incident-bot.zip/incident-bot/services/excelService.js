// ============================================================
//  services/excelService.js
//  Reads & writes incidents to an Excel file using ExcelJS
//  Replace this service with ServiceNow client in production
// ============================================================

const ExcelJS = require('exceljs');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

// Excel file location (from .env or default)
const EXCEL_PATH = process.env.EXCEL_FILE_PATH || './data/incidents.xlsx';

// Column definitions — easy to modify
const COLUMNS = [
  { header: 'Incident ID',      key: 'incidentId',      width: 18 },
  { header: 'Title',            key: 'title',            width: 40 },
  { header: 'Category',         key: 'category',         width: 15 },
  { header: 'Impact',           key: 'impact',           width: 25 },
  { header: 'Urgency',          key: 'urgency',          width: 15 },
  { header: 'Affected Service', key: 'affectedService',  width: 25 },
  { header: 'Description',      key: 'description',      width: 60 },
  { header: 'Reporter',         key: 'reporter',         width: 30 },
  { header: 'Reporter Name',    key: 'reporterName',     width: 25 },
  { header: 'Status',           key: 'status',           width: 12 },
  { header: 'Created At',       key: 'createdAt',        width: 22 },
  { header: 'Updated At',       key: 'updatedAt',        width: 22 }
];

// Header style
const HEADER_STYLE = {
  font: { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 },
  fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F4C81' } },
  alignment: { horizontal: 'center', vertical: 'middle', wrapText: true },
  border: {
    top:    { style: 'thin', color: { argb: 'FF000000' } },
    left:   { style: 'thin', color: { argb: 'FF000000' } },
    bottom: { style: 'thin', color: { argb: 'FF000000' } },
    right:  { style: 'thin', color: { argb: 'FF000000' } }
  }
};

// Row style (alternating)
const ROW_STYLE_EVEN = { fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE8F0FE' } } };
const ROW_STYLE_ODD  = { fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFFFF' } } };

class ExcelService {
  constructor() {
    this._ensureDataDir();
  }

  // ── Ensure ./data directory exists ─────────────────────────
  _ensureDataDir() {
    const dir = path.dirname(path.resolve(EXCEL_PATH));
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`[ExcelService] Created data directory: ${dir}`);
    }
  }

  // ── Load or create workbook ────────────────────────────────
  async _getWorkbook() {
    const workbook = new ExcelJS.Workbook();
    const filePath = path.resolve(EXCEL_PATH);

    if (fs.existsSync(filePath)) {
      await workbook.xlsx.readFile(filePath);
    } else {
      console.log('[ExcelService] Creating new Excel file...');
    }

    return workbook;
  }

  // ── Get or create the Incidents sheet ─────────────────────
  _getSheet(workbook) {
    let sheet = workbook.getWorksheet('Incidents');

    if (!sheet) {
      sheet = workbook.addWorksheet('Incidents', {
        views: [{ state: 'frozen', ySplit: 1 }] // freeze header row
      });

      // Set columns
      sheet.columns = COLUMNS;

      // Style header row
      const headerRow = sheet.getRow(1);
      headerRow.height = 30;
      headerRow.eachCell((cell) => {
        cell.style = HEADER_STYLE;
      });

      // Enable auto-filter
      sheet.autoFilter = {
        from: 'A1',
        to: `${String.fromCharCode(64 + COLUMNS.length)}1`
      };

      console.log('[ExcelService] Created Incidents sheet with headers');
    }

    return sheet;
  }

  // ── Generate incident ID: INC-YYYYMMDD-XXXX ───────────────
  _generateIncidentId() {
    const now = new Date();
    const date = now.toISOString().slice(0, 10).replace(/-/g, '');
    const suffix = uuidv4().split('-')[0].toUpperCase().slice(0, 4);
    return `INC-${date}-${suffix}`;
  }

  // ── CREATE: Add new incident row ───────────────────────────
  async createIncident(data) {
    const workbook = await this._getWorkbook();
    const sheet = this._getSheet(workbook);
    const now = new Date();

    const incident = {
      incidentId:      this._generateIncidentId(),
      title:           data.title || '',
      category:        data.category || '',
      impact:          data.impact || '',
      urgency:         data.urgency || '',
      affectedService: data.affectedService || '',
      description:     data.description || '',
      reporter:        data.reporter || '',
      reporterName:    data.reporterName || '',
      status:          'Open',
      createdAt:       now.toLocaleString('en-GB'),
      updatedAt:       now.toLocaleString('en-GB')
    };

    const rowNumber = sheet.lastRow ? sheet.lastRow.number + 1 : 2;
    const row = sheet.addRow(incident);
    row.height = 20;

    // Alternate row colours
    const isEven = (rowNumber % 2 === 0);
    row.eachCell((cell) => {
      cell.style = {
        ...(isEven ? ROW_STYLE_EVEN : ROW_STYLE_ODD),
        alignment: { wrapText: true, vertical: 'middle' },
        border: {
          top:    { style: 'hair' },
          bottom: { style: 'hair' },
          left:   { style: 'hair' },
          right:  { style: 'hair' }
        }
      };
    });

    await workbook.xlsx.writeFile(path.resolve(EXCEL_PATH));
    console.log(`[ExcelService] ✅ Incident saved: ${incident.incidentId}`);

    return incident;
  }

  // ── READ: Get all incidents ────────────────────────────────
  async getAllIncidents() {
    const workbook = await this._getWorkbook();
    const sheet = this._getSheet(workbook);
    const incidents = [];

    sheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return; // skip header
      const incident = {};
      COLUMNS.forEach((col, idx) => {
        incident[col.key] = row.getCell(idx + 1).value || '';
      });
      incidents.push(incident);
    });

    return incidents;
  }

  // ── READ: Get incident by ID ───────────────────────────────
  async getIncidentById(incidentId) {
    const all = await this.getAllIncidents();
    return all.find(i => i.incidentId === incidentId) || null;
  }

  // ── UPDATE: Change status of an incident ──────────────────
  async updateStatus(incidentId, newStatus) {
    const workbook = await this._getWorkbook();
    const sheet = this._getSheet(workbook);

    let found = false;
    sheet.eachRow((row, rowNumber) => {
      if (rowNumber === 1) return;
      const id = row.getCell(1).value;
      if (id === incidentId) {
        row.getCell(10).value = newStatus;           // Status column
        row.getCell(12).value = new Date().toLocaleString('en-GB'); // UpdatedAt
        found = true;
      }
    });

    if (found) {
      await workbook.xlsx.writeFile(path.resolve(EXCEL_PATH));
    }

    return found;
  }
}

module.exports = { ExcelService };
