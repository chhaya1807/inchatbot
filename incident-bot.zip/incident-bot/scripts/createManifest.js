// ============================================================
//  scripts/createManifest.js
//  Generates the Teams app manifest zip for sideloading
//  Run: node scripts/createManifest.js
// ============================================================

require('dotenv').config({ path: '../.env' });

const fs   = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const APP_ID      = process.env.MicrosoftAppId;
const TUNNEL_URL  = process.env.TUNNEL_URL || 'https://YOUR-TUNNEL-URL.loca.lt';

if (!APP_ID) {
  console.error('❌ MicrosoftAppId not found in .env — run setup.js first');
  process.exit(1);
}

// ── Manifest directory ─────────────────────────────────────
const manifestDir = path.resolve(__dirname, '../manifest');
if (!fs.existsSync(manifestDir)) fs.mkdirSync(manifestDir, { recursive: true });

// ── Teams App Manifest ─────────────────────────────────────
const manifest = {
  "$schema": "https://developer.microsoft.com/en-us/json-schemas/teams/v1.17/MicrosoftTeams.schema.json",
  "manifestVersion": "1.17",
  "version": "1.0.0",
  "id": APP_ID,
  "packageName": "com.yourcompany.incidentbot",
  "developer": {
    "name": "Your Company",
    "websiteUrl": "https://yourcompany.com",
    "privacyUrl": "https://yourcompany.com/privacy",
    "termsOfUseUrl": "https://yourcompany.com/terms"
  },
  "icons": {
    "color": "color.png",
    "outline": "outline.png"
  },
  "name": {
    "short": "Incident Bot",
    "full": "Incident Management Bot"
  },
  "description": {
    "short": "Create and track incidents via chat",
    "full": "An incident management bot for Microsoft Teams. Create incidents through a guided Q&A and track them in your Excel workbook."
  },
  "accentColor": "#0F4C81",
  "bots": [
    {
      "botId": APP_ID,
      "scopes": ["personal", "team", "groupChat"],
      "supportsFiles": false,
      "isNotificationOnly": false,
      "commandLists": [
        {
          "scopes": ["personal", "team", "groupChat"],
          "commands": [
            {
              "title": "new incident",
              "description": "Create a new incident"
            },
            {
              "title": "help",
              "description": "Show available commands"
            },
            {
              "title": "restart",
              "description": "Reset the current conversation"
            }
          ]
        }
      ]
    }
  ],
  "permissions": ["identity", "messageTeamMembers"],
  "validDomains": [
    new URL(TUNNEL_URL.startsWith('http') ? TUNNEL_URL : `https://${TUNNEL_URL}`).hostname
  ]
};

// Write manifest.json
fs.writeFileSync(
  path.join(manifestDir, 'manifest.json'),
  JSON.stringify(manifest, null, 2)
);
console.log('✅ manifest.json written');

// ── Create placeholder icons if they don't exist ───────────
// Teams requires color.png (192x192) and outline.png (32x32)
// These are minimal 1x1 PNGs as placeholders
const colorIconBase64   = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
const outlineIconBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

if (!fs.existsSync(path.join(manifestDir, 'color.png'))) {
  fs.writeFileSync(path.join(manifestDir, 'color.png'), Buffer.from(colorIconBase64, 'base64'));
  console.log('✅ color.png placeholder created (replace with your 192x192 icon)');
}
if (!fs.existsSync(path.join(manifestDir, 'outline.png'))) {
  fs.writeFileSync(path.join(manifestDir, 'outline.png'), Buffer.from(outlineIconBase64, 'base64'));
  console.log('✅ outline.png placeholder created (replace with your 32x32 icon)');
}

// ── Zip the manifest folder ────────────────────────────────
const zipPath = path.join(manifestDir, 'incident-bot.zip');

// Remove old zip if exists
if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

try {
  // Try system zip (works on Mac/Linux)
  execSync(`cd "${manifestDir}" && zip -j incident-bot.zip manifest.json color.png outline.png`);
  console.log(`✅ Manifest zip created: ${zipPath}`);
} catch {
  // Fallback message for Windows
  console.log('⚠️  Could not auto-zip (Windows). Please manually zip these 3 files:');
  console.log(`   📁 ${manifestDir}`);
  console.log('      ├── manifest.json');
  console.log('      ├── color.png');
  console.log('      └── outline.png');
  console.log(`   → Save as: incident-bot.zip`);
}

console.log(`
📋 NEXT: Upload to Teams
  1. Open Microsoft Teams
  2. Go to Apps (left sidebar)
  3. Click "Manage your apps"
  4. Click "Upload an app" → "Upload a custom app"
  5. Select: ${zipPath}
  6. Click Add
`);
