// ============================================================
//  scripts/setup.js
//  ONE-COMMAND SETUP: Creates Azure Bot + App Registration
//  Run: node scripts/setup.js
//
//  Prerequisites:
//    1. Azure CLI installed  → https://aka.ms/installazurecli
//    2. Logged in            → az login
//    3. Node.js installed
// ============================================================

const { execSync, exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

// ── ANSI colours ───────────────────────────────────────────
const c = {
  reset:  '\x1b[0m',
  green:  '\x1b[32m',
  yellow: '\x1b[33m',
  blue:   '\x1b[34m',
  red:    '\x1b[31m',
  bold:   '\x1b[1m',
  cyan:   '\x1b[36m'
};

const log   = (msg) => console.log(`${c.blue}[setup]${c.reset} ${msg}`);
const ok    = (msg) => console.log(`${c.green}✅ ${msg}${c.reset}`);
const warn  = (msg) => console.log(`${c.yellow}⚠️  ${msg}${c.reset}`);
const error = (msg) => console.log(`${c.red}❌ ${msg}${c.reset}`);
const title = (msg) => console.log(`\n${c.bold}${c.cyan}${'─'.repeat(50)}\n  ${msg}\n${'─'.repeat(50)}${c.reset}`);

// ── Run shell command ──────────────────────────────────────
function run(cmd, silent = false) {
  if (!silent) log(`$ ${cmd}`);
  return execSync(cmd, { encoding: 'utf8' }).trim();
}

function runJSON(cmd) {
  const out = run(cmd, true);
  return JSON.parse(out);
}

// ── Prompt user for input ──────────────────────────────────
function prompt(question, defaultVal = '') {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => {
    const display = defaultVal ? `${question} [${defaultVal}]: ` : `${question}: `;
    rl.question(display, (answer) => {
      rl.close();
      resolve(answer.trim() || defaultVal);
    });
  });
}

// ── Check Azure CLI ────────────────────────────────────────
function checkAzCli() {
  try {
    const ver = run('az --version 2>&1 | head -1', true);
    ok(`Azure CLI found: ${ver.split('\n')[0]}`);
  } catch {
    error('Azure CLI not found. Install it: https://aka.ms/installazurecli');
    process.exit(1);
  }
}

// ── Check login ────────────────────────────────────────────
function checkLogin() {
  try {
    const account = runJSON('az account show');
    ok(`Logged in as: ${account.user.name}`);
    ok(`Subscription:  ${account.name} (${account.id})`);
    return account;
  } catch {
    error('Not logged in. Please run: az login');
    process.exit(1);
  }
}

// ── Main setup ─────────────────────────────────────────────
async function main() {
  title('Teams Incident Bot — Azure Setup Script');

  console.log(`${c.yellow}This script will create:
  1. Azure Resource Group
  2. Azure AD App Registration (Bot identity)
  3. Azure Bot Service (Bot Channel Registration)
  4. Enable Microsoft Teams channel
  5. Write your .env file automatically\n${c.reset}`);

  // ── Check prerequisites ──────────────────────────────────
  title('Step 1: Checking Prerequisites');
  checkAzCli();
  const account = checkLogin();

  // ── Collect config ───────────────────────────────────────
  title('Step 2: Configuration');

  const botName        = await prompt('Bot display name', 'IncidentBot-POC');
  const resourceGroup  = await prompt('Resource group name', `${botName}-rg`);
  const location       = await prompt('Azure region', 'eastus');
  const subscriptionId = account.id;

  console.log('');
  log(`Bot Name:       ${botName}`);
  log(`Resource Group: ${resourceGroup}`);
  log(`Location:       ${location}`);
  log(`Subscription:   ${subscriptionId}`);
  console.log('');

  const confirm = await prompt('Proceed? (yes/no)', 'yes');
  if (confirm.toLowerCase() !== 'yes') {
    warn('Setup cancelled.');
    process.exit(0);
  }

  // ── Create Resource Group ────────────────────────────────
  title('Step 3: Creating Resource Group');
  try {
    run(`az group create --name "${resourceGroup}" --location "${location}"`);
    ok(`Resource group created: ${resourceGroup}`);
  } catch (e) {
    warn(`Resource group may already exist: ${e.message}`);
  }

  // ── Create App Registration ──────────────────────────────
  title('Step 4: Creating Azure AD App Registration');
  let appId, appSecret, tenantId;

  try {
    log('Creating app registration...');
    const appReg = runJSON(`az ad app create --display-name "${botName}" --sign-in-audience "AzureADandPersonalMicrosoftAccount"`);
    appId   = appReg.appId;
    tenantId = account.tenantId;
    ok(`App Registration created: ${appId}`);

    log('Creating client secret (password)...');
    const secretResult = runJSON(`az ad app credential reset --id "${appId}" --years 2`);
    appSecret = secretResult.password;
    ok('Client secret created (valid 2 years)');

  } catch (e) {
    error(`Failed to create App Registration: ${e.message}`);
    process.exit(1);
  }

  // ── Create Azure Bot ─────────────────────────────────────
  title('Step 5: Creating Azure Bot Service');
  try {
    log('Creating Azure Bot resource...');
    run(
      `az bot create ` +
      `--resource-group "${resourceGroup}" ` +
      `--name "${botName}" ` +
      `--kind registration ` +
      `--app-type MultiTenant ` +
      `--appid "${appId}" ` +
      `--password "${appSecret}" ` +
      `--location "global" ` +
      `--sku F0`
    );
    ok(`Azure Bot created: ${botName}`);
  } catch (e) {
    // Bot might already exist or resource provider needs registering
    warn(`Bot creation note: ${e.message}`);
  }

  // ── Enable Teams channel ─────────────────────────────────
  title('Step 6: Enabling Microsoft Teams Channel');
  try {
    run(
      `az bot msteams create ` +
      `--resource-group "${resourceGroup}" ` +
      `--name "${botName}"`
    );
    ok('Microsoft Teams channel enabled!');
  } catch (e) {
    warn(`Teams channel note: ${e.message}`);
    warn('You can enable Teams channel manually in Azure Portal → Bot → Channels');
  }

  // ── Write .env file ──────────────────────────────────────
  title('Step 7: Writing .env File');

  const envContent = `# Auto-generated by scripts/setup.js
# Generated: ${new Date().toISOString()}

# ── Azure Bot Credentials ────────────────────────────────────
MicrosoftAppId=${appId}
MicrosoftAppPassword=${appSecret}
MicrosoftAppTenantId=${tenantId}

# ── Bot Server ───────────────────────────────────────────────
PORT=3978

# ── Excel Storage ────────────────────────────────────────────
EXCEL_FILE_PATH=./data/incidents.xlsx

# ── Tunnel URL ───────────────────────────────────────────────
# Fill this in after running: npm run tunnel
# Then update Azure Bot messaging endpoint to: <TUNNEL_URL>/api/messages
TUNNEL_URL=
`;

  const envPath = path.resolve(__dirname, '../.env');
  fs.writeFileSync(envPath, envContent);
  ok(`.env file written to: ${envPath}`);

  // ── Write summary ────────────────────────────────────────
  title('Setup Complete! 🎉');

  console.log(`${c.green}
╔══════════════════════════════════════════════════════════╗
║                    SETUP SUMMARY                         ║
╠══════════════════════════════════════════════════════════╣
║  App ID:         ${appId.padEnd(38)}║
║  Tenant ID:      ${tenantId.padEnd(38)}║
║  Resource Group: ${resourceGroup.padEnd(38)}║
║  Bot Name:       ${botName.padEnd(38)}║
╚══════════════════════════════════════════════════════════╝
${c.reset}`);

  console.log(`${c.yellow}📋 NEXT STEPS:
${c.reset}
  1. Install dependencies:
     ${c.cyan}npm install${c.reset}

  2. Start the bot server:
     ${c.cyan}npm start${c.reset}

  3. In a NEW terminal, start the tunnel:
     ${c.cyan}npm run tunnel${c.reset}
     → Copy the tunnel URL (e.g. https://incident-bot-poc.loca.lt)

  4. Update Azure Bot messaging endpoint:
     ${c.cyan}az bot update --resource-group "${resourceGroup}" --name "${botName}" --endpoint "<TUNNEL_URL>/api/messages"${c.reset}
     OR go to: Azure Portal → ${botName} → Configuration → Messaging endpoint

  5. Create the Teams app manifest:
     ${c.cyan}node scripts/createManifest.js${c.reset}

  6. Upload the manifest zip to Teams:
     Teams → Apps → Upload a custom app → Select ./manifest/incident-bot.zip

  7. Start chatting with your bot in Teams! 🎉
`);

  // Save credentials to a readable file too
  const credsPath = path.resolve(__dirname, '../.credentials.txt');
  fs.writeFileSync(credsPath, `
IMPORTANT — Keep this file secure and do NOT commit to git
==========================================================
App ID:          ${appId}
App Secret:      ${appSecret}
Tenant ID:       ${tenantId}
Resource Group:  ${resourceGroup}
Bot Name:        ${botName}
Created:         ${new Date().toISOString()}
`);
  ok(`Credentials also saved to: .credentials.txt`);
  warn('.credentials.txt is in .gitignore — keep it safe!');
}

main().catch(e => {
  error(`Setup failed: ${e.message}`);
  console.error(e);
  process.exit(1);
});
