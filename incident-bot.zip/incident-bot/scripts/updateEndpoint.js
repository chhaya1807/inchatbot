// ============================================================
//  scripts/updateEndpoint.js
//  Updates Azure Bot messaging endpoint with your tunnel URL
//  Run: node scripts/updateEndpoint.js <tunnel-url>
//  e.g: node scripts/updateEndpoint.js https://xyz.loca.lt
// ============================================================

require('dotenv').config();

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const tunnelUrl = process.argv[2];

if (!tunnelUrl) {
  console.error('Usage: node scripts/updateEndpoint.js <tunnel-url>');
  console.error('Example: node scripts/updateEndpoint.js https://incident-bot-poc.loca.lt');
  process.exit(1);
}

const endpoint = `${tunnelUrl.replace(/\/$/, '')}/api/messages`;

console.log(`\n🔗 Setting messaging endpoint to: ${endpoint}\n`);

// Try to read bot name from .credentials.txt
let botName = process.env.BOT_NAME;
let resourceGroup = process.env.RESOURCE_GROUP;

if (!botName || !resourceGroup) {
  const credsPath = path.resolve(__dirname, '../.credentials.txt');
  if (fs.existsSync(credsPath)) {
    const creds = fs.readFileSync(credsPath, 'utf8');
    const bgMatch = creds.match(/Bot Name:\s+(.+)/);
    const rgMatch = creds.match(/Resource Group:\s+(.+)/);
    if (bgMatch) botName = bgMatch[1].trim();
    if (rgMatch) resourceGroup = rgMatch[1].trim();
  }
}

if (!botName || !resourceGroup) {
  console.error('❌ Bot name / resource group not found.');
  console.error('Set BOT_NAME and RESOURCE_GROUP in .env, or run setup.js first.');
  process.exit(1);
}

try {
  execSync(
    `az bot update --resource-group "${resourceGroup}" --name "${botName}" --endpoint "${endpoint}"`,
    { stdio: 'inherit' }
  );

  console.log(`\n✅ Endpoint updated!`);

  // Update TUNNEL_URL in .env
  const envPath = path.resolve(__dirname, '../.env');
  if (fs.existsSync(envPath)) {
    let envContent = fs.readFileSync(envPath, 'utf8');
    envContent = envContent.replace(/^TUNNEL_URL=.*$/m, `TUNNEL_URL=${tunnelUrl}`);
    fs.writeFileSync(envPath, envContent);
    console.log(`✅ TUNNEL_URL updated in .env`);
  }

  // Regenerate manifest with new URL
  console.log('\n🔄 Regenerating Teams manifest...');
  execSync(`node ${path.join(__dirname, 'createManifest.js')}`, { stdio: 'inherit' });

} catch (e) {
  console.error(`❌ Failed: ${e.message}`);
  console.log('\nManually update in Azure Portal:');
  console.log(`  Portal → ${botName} → Configuration → Messaging endpoint`);
  console.log(`  Set to: ${endpoint}`);
}
