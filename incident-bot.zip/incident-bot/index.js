// ============================================================
//  index.js — Bot entry point
//  Starts the restify server and wires up Bot Framework
// ============================================================

require('dotenv').config();

const path = require('path');
const restify = require('restify');
const {
  BotFrameworkAdapter,
  ConversationState,
  MemoryStorage,
  UserState
} = require('botbuilder');

const { IncidentBot } = require('./bot/incidentBot');

// ── Adapter ────────────────────────────────────────────────
const adapter = new BotFrameworkAdapter({
  appId: process.env.MicrosoftAppId || '',
  appPassword: process.env.MicrosoftAppPassword || ''
});

// Error handler — sends error message back to user
adapter.onTurnError = async (context, error) => {
  console.error('[onTurnError]', error);
  await context.sendActivity('⚠️ Oops! Something went wrong. Please try again or type **restart** to reset.');
  await conversationState.delete(context);
};

// ── State Storage ──────────────────────────────────────────
// Using MemoryStorage for POC — swap with CosmosDB for production
const memoryStorage = new MemoryStorage();
const conversationState = new ConversationState(memoryStorage);
const userState = new UserState(memoryStorage);

// ── Bot ────────────────────────────────────────────────────
const bot = new IncidentBot(conversationState, userState);

// ── Server ────────────────────────────────────────────────
const server = restify.createServer();
server.use(restify.plugins.bodyParser());

server.listen(process.env.PORT || 3978, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════╗');
  console.log('║   🤖 Teams Incident Bot — POC                ║');
  console.log('╠══════════════════════════════════════════════╣');
  console.log(`║  Server:   http://localhost:${process.env.PORT || 3978}           ║`);
  console.log(`║  Endpoint: /api/messages                     ║`);
  console.log('╠══════════════════════════════════════════════╣');
  console.log('║  Set TUNNEL_URL in .env then run:            ║');
  console.log('║  npm run tunnel  (in a second terminal)      ║');
  console.log('╚══════════════════════════════════════════════╝');
  console.log('');
});

// ── Message Endpoint ───────────────────────────────────────
server.post('/api/messages', (req, res) => {
  adapter.processActivity(req, res, async (context) => {
    await bot.run(context);
  });
});

// Health check endpoint
server.get('/health', (req, res, next) => {
  res.send(200, { status: 'ok', timestamp: new Date().toISOString() });
  return next();
});
