// ============================================================
//  bot/incidentBot.js
//  TeamsActivityHandler — routes all incoming activities
// ============================================================

const {
  TeamsActivityHandler,
  CardFactory,
  MessageFactory
} = require('botbuilder');

const { IncidentDialog } = require('../dialogs/incidentDialog');
const { WelcomeCard } = require('../cards/welcomeCard');

class IncidentBot extends TeamsActivityHandler {
  constructor(conversationState, userState) {
    super();

    this.conversationState = conversationState;
    this.userState = userState;
    this.dialog = new IncidentDialog(conversationState, userState);
    this.dialogState = conversationState.createProperty('DialogState');

    // ── Member Added (bot installed / user joins) ──────────
    this.onMembersAdded(async (context, next) => {
      const membersAdded = context.activity.membersAdded;
      for (const member of membersAdded) {
        // Don't greet the bot itself
        if (member.id !== context.activity.recipient.id) {
          await context.sendActivity(
            MessageFactory.attachment(CardFactory.adaptiveCard(WelcomeCard))
          );
        }
      }
      await next();
    });

    // ── Message Handler ────────────────────────────────────
    this.onMessage(async (context, next) => {
      // Strip bot mention from Teams messages
      let text = context.activity.text || '';
      text = text.replace(/<at>.*?<\/at>/gi, '').trim().toLowerCase();

      // Allow "restart" to reset dialog at any time
      if (text === 'restart' || text === 'reset') {
        await this.conversationState.delete(context);
        await context.sendActivity('🔄 Conversation reset. Type **new incident** to start.');
        await next();
        return;
      }

      // Allow "help" at any time
      if (text === 'help') {
        await context.sendActivity(this._getHelpMessage());
        await next();
        return;
      }

      // Route to dialog (handles all Q&A flow)
      await this.dialog.run(context, this.dialogState);
      await next();
    });

    // ── Adaptive Card Action Handler ───────────────────────
    this.onInvokeActivity = async (context) => {
      if (context.activity.name === 'adaptiveCard/action') {
        await this.dialog.run(context, this.dialogState);
      }
    };
  }

  // Save state after every turn
  async run(context) {
    await super.run(context);
    await this.conversationState.saveChanges(context, false);
    await this.userState.saveChanges(context, false);
  }

  _getHelpMessage() {
    return {
      type: 'message',
      text: `**🤖 Incident Bot Help**\n\n` +
        `| Command | Description |\n` +
        `|---|---|\n` +
        `| \`new incident\` | Start creating an incident |\n` +
        `| \`restart\` | Reset current conversation |\n` +
        `| \`help\` | Show this message |\n\n` +
        `During incident creation, just answer each question and confirm at the end.`
    };
  }
}

module.exports = { IncidentBot };
