// ============================================================
//  dialogs/incidentDialog.js
//  Waterfall dialog — guides user through incident creation
// ============================================================

const {
  ComponentDialog,
  WaterfallDialog,
  TextPrompt,
  ChoicePrompt,
  ConfirmPrompt,
  DialogSet,
  DialogTurnStatus,
  CardFactory,
  MessageFactory
} = require('botbuilder');

const { ExcelService } = require('../services/excelService');
const { ConfirmationCard } = require('../cards/confirmationCard');
const { SuccessCard } = require('../cards/successCard');

const WATERFALL_DIALOG = 'WATERFALL_DIALOG';
const TEXT_PROMPT = 'TEXT_PROMPT';
const CHOICE_PROMPT = 'CHOICE_PROMPT';
const CONFIRM_PROMPT = 'CONFIRM_PROMPT';
const INCIDENT_DATA = 'INCIDENT_DATA';

class IncidentDialog extends ComponentDialog {
  constructor(conversationState, userState) {
    super('incidentDialog');

    this.incidentDataAccessor = conversationState.createProperty(INCIDENT_DATA);
    this.excelService = new ExcelService();

    // Register prompts
    this.addDialog(new TextPrompt(TEXT_PROMPT));
    this.addDialog(new ChoicePrompt(CHOICE_PROMPT));
    this.addDialog(new ConfirmPrompt(CONFIRM_PROMPT));

    // Waterfall steps
    this.addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
      this.welcomeStep.bind(this),
      this.askTitleStep.bind(this),
      this.askCategoryStep.bind(this),
      this.askImpactStep.bind(this),
      this.askUrgencyStep.bind(this),
      this.askAffectedServiceStep.bind(this),
      this.askDescriptionStep.bind(this),
      this.askReporterStep.bind(this),
      this.confirmStep.bind(this),
      this.submitStep.bind(this)
    ]));

    this.initialDialogId = WATERFALL_DIALOG;
  }

  // ── Run helper (called from bot) ───────────────────────────
  async run(context, accessor) {
    const dialogSet = new DialogSet(accessor);
    dialogSet.add(this);
    const dialogContext = await dialogSet.createContext(context);
    const results = await dialogContext.continueDialog();
    if (results.status === DialogTurnStatus.empty) {
      await dialogContext.beginDialog(this.id);
    }
  }

  // ── Step 1: Welcome / check intent ────────────────────────
  async welcomeStep(step) {
    const text = (step.context.activity.text || '').toLowerCase().trim();
    const isNewIncident = text.includes('new') || text.includes('incident') ||
                          text.includes('create') || text.includes('report') ||
                          text.includes('start');

    if (!isNewIncident) {
      await step.context.sendActivity(
        `👋 Hi! I'm the **Incident Bot**.\n\n` +
        `Type **new incident** to create an incident, or **help** for more options.`
      );
      return await step.endDialog();
    }

    await step.context.sendActivity(
      `📋 **Let's create a new incident!**\n\nI'll ask you a few questions. ` +
      `Type **restart** at any time to start over.\n\n*Step 1 of 7*`
    );

    return await step.next();
  }

  // ── Step 2: Short title ────────────────────────────────────
  async askTitleStep(step) {
    return await step.prompt(TEXT_PROMPT, {
      prompt: '**📝 Step 1/7 — Title**\n\nPlease provide a short title for the incident:\n*(e.g. "Login page not loading")*'
    });
  }

  // ── Step 3: Category ───────────────────────────────────────
  async askCategoryStep(step) {
    // Save title from previous step
    const data = await this.incidentDataAccessor.get(step.context, {});
    data.title = step.result;
    await this.incidentDataAccessor.set(step.context, data);

    return await step.prompt(CHOICE_PROMPT, {
      prompt: '**🏷️ Step 2/7 — Category**\n\nWhat category best describes this incident?',
      choices: ['💻 Software', '🔧 Hardware', '🌐 Network', '🔒 Security', '📦 Other'],
      style: 1 // SuggestedAction style
    });
  }

  // ── Step 4: Impact ─────────────────────────────────────────
  async askImpactStep(step) {
    const data = await this.incidentDataAccessor.get(step.context, {});
    data.category = step.result.value.replace(/^[^\w]+/, '').trim(); // strip emoji
    await this.incidentDataAccessor.set(step.context, data);

    return await step.prompt(CHOICE_PROMPT, {
      prompt: '**⚡ Step 3/7 — Impact**\n\nWhat is the business impact?',
      choices: ['🔴 High — Business critical', '🟡 Medium — Significant slowdown', '🟢 Low — Minor issue'],
      style: 1
    });
  }

  // ── Step 5: Urgency ────────────────────────────────────────
  async askUrgencyStep(step) {
    const data = await this.incidentDataAccessor.get(step.context, {});
    data.impact = step.result.value.replace(/^[^\w]+/, '').trim();
    await this.incidentDataAccessor.set(step.context, data);

    return await step.prompt(CHOICE_PROMPT, {
      prompt: '**🚨 Step 4/7 — Urgency**\n\nHow urgently does this need to be resolved?',
      choices: ['1 - Critical', '2 - High', '3 - Medium', '4 - Low'],
      style: 1
    });
  }

  // ── Step 6: Affected Service ───────────────────────────────
  async askAffectedServiceStep(step) {
    const data = await this.incidentDataAccessor.get(step.context, {});
    data.urgency = step.result.value;
    await this.incidentDataAccessor.set(step.context, data);

    return await step.prompt(TEXT_PROMPT, {
      prompt: '**🖥️ Step 5/7 — Affected Service**\n\nWhich service or system is affected?\n*(e.g. "Customer Portal", "Email Server", "VPN")*'
    });
  }

  // ── Step 7: Description ────────────────────────────────────
  async askDescriptionStep(step) {
    const data = await this.incidentDataAccessor.get(step.context, {});
    data.affectedService = step.result;
    await this.incidentDataAccessor.set(step.context, data);

    return await step.prompt(TEXT_PROMPT, {
      prompt: '**📄 Step 6/7 — Description**\n\nPlease describe the issue in detail:\n*(What happened? When did it start? Any error messages?)*'
    });
  }

  // ── Step 8: Reporter email ─────────────────────────────────
  async askReporterStep(step) {
    const data = await this.incidentDataAccessor.get(step.context, {});
    data.description = step.result;
    await this.incidentDataAccessor.set(step.context, data);

    // Try to auto-fill from Teams user profile
    const teamsUser = step.context.activity.from;
    const defaultEmail = teamsUser?.email || '';

    return await step.prompt(TEXT_PROMPT, {
      prompt: `**👤 Step 7/7 — Your Email**\n\nWhat is your email address?` +
        (defaultEmail ? `\n\n*(Press Enter to use: ${defaultEmail})*` : '')
    });
  }

  // ── Step 9: Confirmation card ──────────────────────────────
  async confirmStep(step) {
    const data = await this.incidentDataAccessor.get(step.context, {});

    // Use typed email or fallback to Teams profile
    const typedEmail = step.result?.trim();
    data.reporter = typedEmail && typedEmail !== '' ? typedEmail :
                    (step.context.activity.from?.email || step.context.activity.from?.name || 'Unknown');
    data.reporterName = step.context.activity.from?.name || data.reporter;

    await this.incidentDataAccessor.set(step.context, data);

    // Show confirmation adaptive card
    const card = ConfirmationCard(data);
    await step.context.sendActivity(
      MessageFactory.attachment(CardFactory.adaptiveCard(card))
    );

    return await step.prompt(CONFIRM_PROMPT, {
      prompt: '✅ **Shall I submit this incident?** (yes / no)'
    });
  }

  // ── Step 10: Submit to Excel ───────────────────────────────
  async submitStep(step) {
    if (!step.result) {
      await step.context.sendActivity(
        '❌ Incident cancelled. Type **new incident** to start again.'
      );
      return await step.endDialog();
    }

    const data = await this.incidentDataAccessor.get(step.context, {});

    await step.context.sendActivity('⏳ Creating incident...');

    try {
      const incident = await this.excelService.createIncident(data);

      // Show success card
      const card = SuccessCard(incident);
      await step.context.sendActivity(
        MessageFactory.attachment(CardFactory.adaptiveCard(card))
      );
    } catch (error) {
      console.error('Excel save error:', error);
      await step.context.sendActivity(
        `❌ Failed to save incident: ${error.message}\n\nPlease contact your admin.`
      );
    }

    // Clear incident data
    await this.incidentDataAccessor.set(step.context, {});
    return await step.endDialog();
  }
}

module.exports = { IncidentDialog };
